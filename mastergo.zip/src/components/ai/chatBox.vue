<script setup>
import { marked } from 'marked'
import { ref, watch, nextTick, onMounted } from 'vue'
import { useQwenAI } from './qwenAI'
import { useAiChatStore } from '@/stores'
import { storeToRefs } from 'pinia'
const aiChatStore = useAiChatStore()
const { chatMsgs } = storeToRefs(aiChatStore)
const { removeChatMsg, addChatMsg, setSelectedElement, setIsRequireAIChange } = aiChatStore
const { selectedElement, iframeEntrance } = storeToRefs(aiChatStore)
const userInput = ref('')
const sendBtn = ref(null)
const chatContainer = ref(null)
const { getResponse } = useQwenAI()
onMounted(() => {
  scrollToBottom()
})
// 添加滚动到底部的函数
const scrollToBottom = async () => {
  await nextTick() // 等待 DOM 更新
  const container = chatContainer.value
  if (container) {
    container.scrollTop = container.scrollHeight
  }
}
// 监听消息列表变化，自动滚动到底部
watch(
  chatMsgs,
  () => {
    scrollToBottom()
  },
  {
    deep: true, // 深度监听
    immediate: true, // 立即触发
  },
)
const sendMessage = async () => {
  let parsedContent = ''

  const trueMessage = selectedElement.value.outerHTML
    ? `${userInput.value} 。待修改组件代码如下：${selectedElement.value.outerHTML}`
    : userInput.value
  try {
    //禁用发送按钮
    sendBtn.value.disabled = true

    addChatMsg({
      id: chatMsgs.value.length + 1,
      message: userInput.value,
      content: trueMessage,
      role: 'user',
      selectedElement: null,
      newElement: null,
    })
    const loadingMsg = '牧濑正在思考...'
    addChatMsg({
      id: 0,
      message: loadingMsg,
      content: trueMessage,
      role: 'assistant',
      selectedElement: null,
      newElement: null,
    })

    const res = await getResponse(trueMessage)

    parsedContent = marked.parse(res)

    userInput.value = ''
  } catch (error) {
    console.log(error)
    throw error
  } finally {
    //移除loadingMsg
    removeChatMsg(0)
    const newElement = parseAIResponse(parsedContent)
    addChatMsg({
      id: chatMsgs.value.length + 1,
      message: parsedContent,
      content: parsedContent,
      role: 'assistant',
      selectedElement: selectedElement.value,
      newElement: newElement,
    })
    //启用发送按钮
    sendBtn.value.disabled = false
  }
}
//提取回答中的组件代码
function parseAIResponse(response) {
  const parser = new DOMParser()
  const doc = parser.parseFromString(response, 'text/html')

  // 提取 HTML 部分
  const htmlElement = doc.querySelector('.language-html')
  const htmlContent = htmlElement ? htmlElement.textContent.trim() : ''

  // 提取 CSS 部分
  const cssElement = doc.querySelector('.language-css')
  const cssContent = cssElement ? cssElement.textContent.trim() : ''

  return { html: htmlContent, css: cssContent }
}
const insertElement = (id) => {
  const msg = chatMsgs.value.find((item) => item.id === id)
  console.log(msg)
  //先移除选中元素的特殊高亮
  msg.selectedElement.classList.remove('special-hover-highlight')
  //关闭ai修改
  setIsRequireAIChange(false)
  //插入元素
  msg.selectedElement.outerHTML = msg.newElement.html
  //插入css
  const styleTag = iframeEntrance.value.createElement('style')
  styleTag.textContent = msg.newElement.css
  iframeEntrance.value.head.appendChild(styleTag)
  //清空选中元素
  setSelectedElement(null)
}
</script>

<template>
  <div class="chat-box">
    <div id="chat-container" ref="chatContainer">
      <div
        v-for="item in chatMsgs"
        :key="item.id"
        :class="{ 'user-message': item.role === 'user', 'ai-message': item.role === 'assistant' }"
      >
        <div v-if="item.role === 'user'" v-html="item.message" class="message-content"></div>

        <div v-if="item.role === 'assistant'" v-html="item.message" class="message-content"></div>
        <div v-if="item.role === 'assistant' && item.id !== 0" class="tools">
          <button @click="insertElement(item.id)">应用</button>
          <button>撤销</button>
          <button>保存到组件库</button>
        </div>
      </div>
    </div>
    <div id="input-container">
      <input type="text" id="user-input" placeholder="输入你的问题..." v-model="userInput" />
      <button id="send-btn" ref="sendBtn" @click="sendMessage">发送</button>
    </div>
  </div>
</template>
<style scoped lang="less">
.chat-box {
  width: 100%;
  height: 100%;

  #chat-container {
    width: 100%;
    height: 90%;
    background-color: #f0f0f0;
    overflow-y: auto;
    scroll-behavior: smooth;
    display: flex;
    flex-direction: column;
    gap: 20px;
  }
  #input-container {
    width: 100%;
    height: 10%;
    background-color: #f0f0f0;
  }
  .user-message {
    display: flex;
    flex-direction: row-reverse;
    width: 95%;
    margin: auto;

    .message-content {
      max-width: 80%;
      background-color: #f0f0f0;

      font-size: 16px;
      padding: 8px 10px;
      border-radius: 10px;
      background-color: rgba(255, 255, 255, 0.9);
      overflow-y: auto;
    }
  }
  .ai-message {
    display: flex;
    flex-direction: row;
    width: 95%;
    margin: auto;
    margin-bottom: 30px;
    position: relative;
    .tools {
      position: absolute;
      bottom: -30px;
      left: 0;
      display: flex;
      flex-direction: row;
      gap: 10px;
      button {
        background-color: #008000;
        border: none;
        padding: 5px 10px;
        border-radius: 5px;
        color: #fff;
      }
    }
    .message-content {
      max-width: 100%;
      background-color: #f0f0f0;
      text-align: left;
      font-size: 16px;
      padding: 8px 10px;
      border-radius: 10px;
      background-color: rgba(255, 255, 255, 0.9);
      overflow-y: auto;
    }
  }
}
</style>
