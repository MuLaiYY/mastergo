<script setup lang="ts">
import { RouterView } from 'vue-router'
</script>

<template>
  <RouterView />
</template>
<style lang="less">
body {
  overflow-x: hidden;
}
</style>
